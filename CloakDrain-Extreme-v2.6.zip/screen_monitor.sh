#!/system/bin/sh
STATUS_FILE=/data/adb/cloakdrain_status
LOGFILE=/data/adb/cloakdrain_log.txt

touch $LOGFILE

screen_state_monitor() {
  while read -r line; do
    case "$line" in
      *"change@/devices/virtual/switch/state"*)
        state=$(cat /sys/class/switch/state 2>/dev/null)
        if [ "$state" = "0" ]; then
          echo "🔒 Screen off → CloakDrain ON" >> $LOGFILE
          /system/bin/cloakdrain on
        else
          echo "🔓 Screen on → CloakDrain OFF" >> $LOGFILE
          /system/bin/cloakdrain off
        fi
        ;;
    esac
  done
}

/system/bin/ueventd | screen_state_monitor
