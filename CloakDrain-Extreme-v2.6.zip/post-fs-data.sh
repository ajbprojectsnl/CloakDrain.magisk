#!/system/bin/sh
# Setup persistent status file
[ ! -f /data/adb/cloakdrain_status ] && echo "on" > /data/adb/cloakdrain_status
