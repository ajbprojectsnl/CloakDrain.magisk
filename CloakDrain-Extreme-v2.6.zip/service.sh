#!/system/bin/sh
STATUS_FILE=/data/adb/cloakdrain_status
[ "$(cat $STATUS_FILE 2>/dev/null)" != "on" ] && exit 0

# CPU governor and freq cap - set twice to be persistent
for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
  echo "powersave" > $cpu/cpufreq/scaling_governor 2>/dev/null
  echo 1026000 > $cpu/cpufreq/scaling_max_freq 2>/dev/null
  sleep 0.2
  echo 1026000 > $cpu/cpufreq/scaling_max_freq 2>/dev/null
done

# Alarm throttling
settings put global alarm_manager_constants "min_futurity=60000,alarm_batch_delay=30000"

# Background data disable
settings put global background_data 0

# Wifi scan throttling
settings put global wifi_scan_throttle_enabled 1

# Disable location & sensors
settings put secure location_mode 0
settings put secure sensors_off 1

# Disable known apps if installed
for app in com.facebook.katana com.tiktok.android; do
  pm list packages | grep -q "$app" && pm disable-user $app 2>/dev/null
done
